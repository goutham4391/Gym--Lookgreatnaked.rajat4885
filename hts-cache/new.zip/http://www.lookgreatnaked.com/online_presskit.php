<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Online Press Kit for Brad Scoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Online Press Kit</h2>
						<div class="article">							
							<h3>Brad Schoenfeld's Online Press Kit</h3>
							<p>Here you'll find pertinent info about Brad's fitness background as well as a small sampling of the hundreds of print, radio, and media appearances Brad has done over the years. Images are clickable for easy viewing. For booking, please <a href="contact_brad.php">Contact Us.</a></p>
                            <p style="clear:both; height:12px;"></p>	
                            <h3>Background Information</h3>
                            <hr />
                            <div class="press_wrapper">
                              <div class="press_left">
                                <p><a href="media/bradsbio.pdf" target="_blank"><img class="icon_image" src="images/media/pdf_icon.png" alt="Brad's Bio" width="49" height="53" align="left"></a><b>Brad's Bio</b><br />Read about Brad's unparalleled experience as a fitness expert</font>.</p><br />
                              </div>
                              <div class="press_right">
                                <p><a href="media/bradqanda.pdf" target="_blank"><img class="icon_image" src="images/media/pdf_icon.png" alt="Brad Schoenfeld FAQs" width="49" height="53" align="left"></a><b>Q &amp; A</b><br />Brad answers frequently asked questions</p><br />
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/mediaappearances.pdf" target="_blank"><img class="icon_image" src="images/media/pdf_icon.png" alt="Brad Schoenfeld Media Appearances" width="49" height="53" align="left"></a><b>Media Appearances</b><br />A partial list of where Brad has appeared.</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/angles.pdf" target="_blank"><img class="icon_image" src="images/media/pdf_icon.png" alt="Brad Schoenfeld Story Angles" width="49" height="53" align="left"></a><b>Story Angles</b><br />Brad can turn these ideas into a dynamic feature story.</p>
                              </div>
                            </div>					
							<p style="clear:both; height:12px;"></p>
                            <h3>Selected Articles</h3>
                            <hr>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/cosmo1.pdf" target="_blank"><img class="about_image" src="images/media/cosmo11.jpg" alt="Cosmo article" width="50" height="64" align="left"></a><b>Cosmopolitan</b><br />"Get toned legs."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/fitness1.pdf" target="_blank"><img class="about_image" src="images/media/fitness21.jpg" alt="Fitness article" width="50" height="64" align="left"></a><b>Fitness</b><br />"Drop 5 pounds in 4 weeks!"</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/marieclaire.pdf" target="_blank"><img class="about_image" src="images/media/marieclaire11.jpg" alt="Marie Claire article" width="50" height="70" align="left"></a><b>Marie Claire</b><br />"14 Days to Your Flattest Abs Ever."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/self1.pdf" target="_blank"><img class="about_image"  src="images/media/self21.jpg" alt="Self article" width="50" height="71" align="left"></a><b>Self</b><br />"No Sleeves, No Problem."</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/fitrx1.pdf" target="_blank"><img class="about_image" src="images/media/fitrx11.jpg" alt="Fit Rx article" width="50" height="68" align="left"></a><b>Fitness RX for Women</b><br />"Look Great Sleeveless."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/cookinglight.pdf"><img class="about_image" src="images/media/cooking1.jpg" alt="Cooking Light article" width="50" height="68" align="left"></a><b>Cooking Light</b><br />"Maximum Glutes."</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/first.pdf" target="_blank"><img class="about_image" src="images/media/first1.jpg" alt="First for Women article" width="50" height="65" align="left"></a><b>First for Woment</b><br />"Little Bust Beautifiers."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/familycircle.pdf" target="_blank"><img class="about_image" src="images/media/family1.jpg" alt="Family Circle article" width="50" height="66" align="left"></a><b>Family Circle</b><br />"High-Energy, Low-Calorie Treats."</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/letslive.pdf" target="_blank"><img class="about_image" src="images/media/letslive1.jpg" alt="Let's Live article" width="50" height="68" align="left"></a><b>Let's Live</b> <br>"Ab Myths and Magic."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/oxygen.pdf" target="_blank"><img class="about_image" src="images/media/oxygen1.jpg" alt="Oxygen article" width="50" height="65" align="left"></a><b>Oxygen</b><br>"New Year, New You."</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/complete.pdf" target="_blank"><img class="about_image" src="images/media/complete1.jpg" alt="NY Times" width="50" height="64" align="left"></a><b>Complete Woman</b><br />"The Look Great Naked Diet."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/cosmo2.pdf" target="_blank"><img class="about_image" src="images/media/cosmo21.jpg" alt="Cosmo article" width="50" height="65" align="left"></a><b>Cosmopolitan</b> <br>"Tone Your Tush"</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/fitness2.pdf" target="_blank"><img class="about_image"  src="images/media/fitness11.jpg" alt="Fitness article" width="50" height="68" align="left"></a><b>Fitness</b><br>"Bottom's Up."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/self2.pdf" target="_blank"><img class="about_image" src="images/media/self21.jpg" alt="Self article" width="50" height="65" align="left"></a><b>Self</b><br>"Try a Microworkout."</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/allyou.pdf" target="_blank"><img class="about_image" src="images/media/allyou1.jpg" alt="All You article" width="50" height="64" align="left"></a><b>All You</b><br>"Get a Better Body by New Years."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/fitrx2.pdf" target="_blank"><img class="about_image" src="images/media/fitrx21.jpg" alt="Fit Rx article" width="50" height="65" align="left"></a><b>Fitness Rx for Women</b><br>"Sculpting Her Body Perfect."</p>
                              </div>
                            </div>
                            
                            <p style="clear:both; height:12px;"></p>
                            <h3>Video Clips</h3>
                            <hr />
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/foxnewsclip.wmv" width=340 height=220><img class="about_image" src="images/media/foxnewschannel.jpg" alt="Fox Newschannel" width="80" height="60" align="left"></a><b>Fox Newschannel</b><br>(02:25)<br>"Work it!"</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/foxclip.wmv" width=340 height=220><img class="about_image" src="images/media/foxclip.jpg" alt="Good Day NY" width="80" height="59" align="left"></a><b>Good Day NY</b> <br />(02:31)<br>"Target training"</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/gooddaylaclip.wmv" width=340 height=220><img class="about_image" src="images/media/gooddayla.jpg" alt="Good Day LA" width="80" height="60" align="left"></a><b>Good Day LA</b><br />(04:50)<br>"Slim, Shape and Tone"</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/today_in_ny_whwb_1-17-10.wmv" width=340 height=220><img class="about_image" src="images/media/todayinny.jpg" alt="Today in NY" width="80" height="60" align="left"></a><b>Today in New York</b><br />(04:10)<br>"Home Gym"</p>
                              </div>
                            </div>
                            <div class="press_wrapper">
                              <div class="press_left">
                              <p><a href="media/gooddaypaclip.wmv" width=340 height=220><img class="about_image" src="images/media/gooddaypa.jpg" alt="Good Day Philadelphia" width="80" height="60" align="left"></a><b>Good Day Philadelphia</b><br>(01:12)<br>"Shapeover."</p>
                              </div>
                              <div class="press_right">
                              <p><a href="media/wb11clip.wmv" width=340 height=220><img class="about_image" src="images/media/wb11.jpg" alt="WB11 Morning News" width="80" height="59" align="left"></a><b>WB11 Morning</b><br>(04:10)<br>"Naked Workout"</p>
                              </div>
                            </div>
                            <p style="clear:both; height:12px;"></p>
						</div>
						<p style="clear:both; height:12px;"></p>
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
