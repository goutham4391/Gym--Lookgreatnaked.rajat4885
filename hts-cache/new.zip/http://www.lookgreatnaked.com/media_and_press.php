<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Media and Press for Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Media and Press</h2>
						<div class="article">							
							
							<p>Welcome to our media room. Brad Schoenfeld, CSCS has been a leader in the fitness field for almost two decades. Find out why here.</p>
                            <h3>Online Press Kit</h3>
                            <p><a href="online_presskit.php"><img class="about_image" src="images/layout/presskit.jpg" width=75> <a href="online_presskit.php"><span style="vertical-align: top; font-size:20px;">Click Here for the On-Line Press Kit</span></a></p>
							<h3>News Releases</h3>
							<p><a href="media/newsreleases.html"><img class="about_image" src="images/layout/extra.jpg" width=75> <a href="news_releases.php"><span style="vertical-align: top; font-size:20px;">Click Here for the News Releases</span></a></p>							
							<p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
