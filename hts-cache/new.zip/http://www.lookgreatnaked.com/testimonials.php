<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Testimonials for Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Testimonials</h2>
						<div class="article">							
							<p>Here is what others are saying about Brad Schoenfeld, CSCS.</p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Bret_Contreras.jpg" width=160 align=left>"As far as I'm concerned, Brad Schoenfeld is the world's expert on muscle hypertrophy. I've learned a ton from him over the past few years and you will too. Another thing I love about Brad is his commitment to science and the evidence-based process, so his views flow with the advancement of research. You won't meet anyone as passionate about the science of muscle growth than Brad, and he's been very generous with his knowledge! Thanks Brad, you are appreciated!"<br /><br /><b>Bret Contreras</b><br />Fitness<br /><a href="http://www.bretcontreras.com" target="blank">http://www.bretcontreras.com</a></p>
							<hr />
                            <p><img class="about_image" src="images/testimonials/Layne_Norton.JPG" width=160 align=left>"Brad has demonstrated time and time again why he is one of the premier scientists in exercise science. Not only has he published numerous peer reviewed articles, he also has written books, articles, and utilized other media to relay complex information to the lay person for consumption. He is exactly the type of person that the fitness industry needs." <br /><br /><b>Layne Norton</b><br />Champion Natural Bodybuilder<br /><a href="http://www.biolayne.com" target="blank">www.biolayne.com</a></p>	
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Ben_Pakulski.jpg" width=160 align=left>"The fitness and muscle building world has been misled for decades. In recent years a few individuals have set themselves apart as the people bringing true value and scientifically verified information to the masses. Brad Schoenfeld is definitely one of these leaders. He is blazing a path to greatness and helping us all succeed in our muscle building and fat loss journeys."<br /><br /><b>Ben Pakulski</b><br />IFBB Professional Bodybuilder<br /><a href="http://www.benpakulski.com" target="blank">www.benpakulski.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Shonna_McCarver.JPG" width=160 align=left>"Before I met Brad, I just worked out to be in shape. Brad helped me take it to a new level. Now I know what I will gain from each exercise."<br /><br /><b>Shonna McCarver</b><br />Fitness Cover Model</p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Eric_Cressey.jpg" width=160 align=left>"With his research and writing, Brad Schoenfeld has done a tremendous job of bringing more clarity to why we program for athletes and clients the way we do. However, unlike many researchers who've never trained clients or themselves, he walks the walk. I really enjoy his writing - and have benefited from it."<br /><br /><b>Eric Cressey</b><br />President, Cressey Performance - Hudson, MA<br /><a href="http://www.EricCressey.com" target="blank">http://www.ericcressey.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Lou_Schuler.jpg" width=160 align=left>"Brad Schoenfeld is one of my heroes in the fitness industry. His research revisits a question that mainstream exercise scientists stopped asking years ago: 'What makes muscles grow?' The answers Brad finds shed new light on a subject many of us foolishly reduced to 'lift heavy things.' Brad's work is indispensable to journalists like me, along with all the gym rats and fitness nerds looking for new ways to achieve the ancient goal of looking better than we do now."<br /><br /><b>Lou Schuler</b><br />Author of the "New Rules of Lifting" series<br /><a href="http://www.louschuler.com" target="blank">http://www.louschuler.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Joe_Dowdell.jpg" width=160 align=left>�Over the years, I�ve had the unique opportunity to spend time with many of the brightest minds in the health and fitness industry. Without a doubt, Brad Schoenfeld is one of those people. His relentless passion coupled with an egoless approach to exercise science is extraordinary.�<br /><br /><b>Joe Dowdell</b><br />Founder & CEO of Peak Performance<br /><a href="http://www.peakperformancenyc.com" target="blank">http://www.peakperformancenyc.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/John_Meadows.jpg" width=160 align=left>"When I talk about hypertrophy, I frequently refer to Brad and his work. I call him the modern day "Godfather of Hypertrophy Science". Brad has a brilliant combination of technical expertise, and in the trenches field experience. He combines both well, and is rightly recognized as one of the best in business! When Brad speaks, I listen."<br /><br /><b>John Meadows</b><br />Nationally Ranked Bodybuilder and Trainer<br /><a href="http://www.mountaindogdiet.com" target="blank">http://www.mountaindogdiet.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/Alan_Aragon.jpg" width=160 align=left>"Brad is a close friend and colleague of mine, but I still wouldn't be biased to say that his contributions to the allied fields of exercise and nutrition have educated and inspired many of the top guys in the fitness industry. He sets the prime example of being an accomplished athlete, coach, and scientist - all while staying humble, gracious, and down-to-earth. Brad is one of the greatest teachers I've had the pleasure to work with and learn from. Let me emphasize that this testimonial isn't hype; it's an understatement."<br /><br /><b>Alan Aragon</b><br />Publisher/Alan Aragon's Research Review<br /><a href="http://www.alanaragon.com" target="blank">http://www.alanaragon.com</a></p>
                            <hr />
                            <p><img class="about_image" src="images/testimonials/TC_Luoma.jpg" width=160 align=left>"I've worked with a lot of guys with impressive science degrees in muscle phys or nutrition, but it often comes with a price -- the science ruins them. What I mean by that is that they get mentally constipated � they memorize the facts but then can't apply them or make a deductive leap of any kind. It's really remarkable and kind of sad. I see it over and over again. Brad, however, is a different kind of animal, a scientist who absorbs and/or conducts research, makes a novel deductive leap or hypothesis, and then tests it out in the gym to see if it works. More often than not, his assumptions are dead on and the result is muscle. Lots of it."<br /><br /><b>TC Luoma</b><br />Editor-in-Chief<br />T Nation</p>
                            <hr />
														<p><img class="about_image" src="images/testimonials/Adam_Bornstein.jpg" width=160 align=left>"I work with the biggest and brightest names in the fitness industry, and I always need to find the best sources for quality information. When it comes to building muscle, Brad Schoenfeld is one of the first people I contact to help bridge the gap between what is happening in the world of science and workouts being created on the training floor. He provides the perfect combination for real world results."<br /><br /><b>Adam Bornstein</b><br />New York Times Best-selling author, award-winning fitness writer and editor<br /><a href="http://www.bornfitness.com" target="blank">http://www.bornfitness.com</a></p>
                            <hr />
                            														<!--<hr />
                            <p><img class="about_image" src="images/testimonials/user.jpg" width=160 align=left><br /><br /><b>Name</b><br />Title<br /><a href="http://www.lookgreatnaked.com">http://www.lookgreatnaked.com</a></p>-->
                           			
							<p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
