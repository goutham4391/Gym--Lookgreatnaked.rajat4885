<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Newsletter for LookGreatNaked.com</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Newsletter</h2>
						<div class="article">							
							<p>Keep up to date with the science of building muscle and losing fat. My newsletter, Scientific Muscle, provides cutting-edge information on training, nutrition and sports supplementation. Best of all-it's <strong>FREE!</strong> You'll receive our newsletter via e-mail on a regular basis.</p>
                            <p>My pledge: The newsletter is dedicated to providing you, the reader, with quality information about fitness. I will never share the list with anyone or send you unwanted spam. </p>
							<div class="press_wrapper">
                            	<!-- Begin MailChimp Signup Form -->
                                <p style="clear:both; height:12px;"></p>
                                <div id="mc_embed_signup">
                                <form action="http://lookgreatnaked.us3.list-manage2.com/subscribe/post?u=fc9b47dc756904876d4befaf8&amp;id=8dd0e01c39" method="post" id="mc-embedded-subscribe-form" name="mc-embedded-subscribe-form" class="validate" target="_blank" novalidate>
                                    <h3 style="text-align:center;">Subscribe to Brad Schoenfeld's<br /> Scientific Muscle newsletter</h3>
                                <div class="indicates-required"><span class="asterisk">*</span> indicates required</div>
                                
                                <div class="mc-field-group">
                                    <label for="mce-EMAIL">Email Address  <span class="asterisk">*</span>
                                </label>
                                    <input type="email" value="" name="EMAIL" class="required email" id="mce-EMAIL">
                                </div>
                                
                                <div class="mc-field-group">
                                    <label for="mce-FNAME">First Name </label>
                                    <input type="text" value="" name="FNAME" class="" id="mce-FNAME">
                                </div>
                                <div class="mc-field-group">
                                    <label for="mce-LNAME">Last Name </label>
                                    <input type="text" value="" name="LNAME" class="" id="mce-LNAME">
                                </div>
                                
                                <div class="mc-field-group input-group">
                                    <strong>Email Format </strong>
                                    <ul><li><input type="radio" value="html" name="EMAILTYPE" id="mce-EMAILTYPE-0"><label for="mce-EMAILTYPE-0">html</label></li>
                                <li><input type="radio" value="text" name="EMAILTYPE" id="mce-EMAILTYPE-1"><label for="mce-EMAILTYPE-1">text</label></li>
                                </ul>
                                </div>
                                    <div id="mce-responses" class="clear">
                                        <div class="response" id="mce-error-response" style="display:none"></div>
                                        <div class="response" id="mce-success-response" style="display:none"></div>
                                    </div>    <!-- real people should not fill this in and expect good things - do not remove this or risk form bot signups-->
                                    <div style="position: absolute; left: -5000px;"><input type="text" name="b_fc9b47dc756904876d4befaf8_8dd0e01c39" value=""></div>
                                    <div class="clear"><input type="submit" value="Subscribe" name="subscribe" id="mc-embedded-subscribe" class="button"></div>
                                </form>
                                </div>
                                
                                <!--End mc_embed_signup-->
                            </div>							
							<p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
