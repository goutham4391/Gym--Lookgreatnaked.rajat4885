<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Competition Coaching with Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Products and Services</h2>
						<div class="article">							
							<h3>Competition Coaching</h3>
							<p><img class="about_image" src=images/layout/bb.jpg width="300" align=right hspace=10 vspace=0 alt="Ccmpetition Coaching">Are you a bodybuilder, physique, or figure competitor seeking to maximize your potential? Don't leave your competition fate to chance. Let renowned training and nutrition expert <a href="about_brad.php" target="blank">Brad Schoenfeld, PhD, CSCS, FNSCA</a> guide you to competitive success.</p>
                            <p>Brad is the fitness pro that serious physique athletes turn to for competition help. He has worked with hundreds of top level competitors--including many champions--helping them achieve their personal best. Whether you're a first timer or seasoned pro, he can do the same for you...</p>
                            <p>Through the power of the internet, our unique online competition coaching program now provides serious physique competitors the opportunity to work one-on-one with Brad regardless of where you live. Our diverse services include:</p>
                            <div style="padding-left: 80px; padding-right: 80px;">
                            <p><b>Competition Training:</b> After a thorough analysis of your strengths and weaknesses, Brad will construct weekly routines tailored specifically to your needs. He'll employ advanced, cutting-edge body sculpting techniques designed to accentuate your genetic assets while masking your flaws. And he'll work with you as your training progresses, tweaking your routine to assure that you develop just the right blend of muscularity and symmetry for your chosen contest.</p>
							<p><b>Competition Diet:</b> Physique competition success requires strict attention to nutrition. It's at least as important as your training--perhaps more so. But contrary to popular belief, there is no one meal plan that's right for everyone. Individual physiology dictates that people respond differently to different food sources. Brad will analyze your body type and help to find just the right balance of macronutrients to optimize muscle while stripping away subcutaneous fat to their lowest possible levels.</p>
                            <p><b>Posing:</b> It's not just having a great physique that wins competitions; it's knowing how to best show off your physique to the judges. Brad knows how judges think; he's served on the judging panel for numerous fitness organizations. He will teach you the tricks of the trade, helping you get the most out of your mandatory poses and working with you to develop a stage presence that commands attention.</p>
                            <p><b>Pre-Contest Prep:</b> Many aspiring competitors fail to realize that what you do in the final week or two before a competition is what ultimately determines your contest placing. Proper manipulation of training variables and nutrient intake is vital to success. When properly integrated, techniques such as carb loading/depletion and sodium alteration can give you the edge you need to rise above the crowd. This is where the real science and art of competition comes into play. Do it right and you get a physique that's hard and defined; do it wrong and you end up  puffy and bloated. Brad knows the ins and outs of pre-contest prep better than anyone. He will walk you through the process, ensuring you are your best on contest day.</p>
                            </div>
                            <p>Ready to get serious? Contact us today by clicking on the link below. Remember, the difference between winning your show or being an also ran is determined by whether you have the proper plan in place.</p>
                            <p><a href="mailto:brad@lookgreatnaked.com?subject=Competition Coaching">Competition Coaching</a></p>							
							<p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
