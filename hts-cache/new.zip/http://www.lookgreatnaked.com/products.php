<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Global Fitness Services - Products and Services Offered By Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Products and Services</h2>
						<div class="article">
                        	<p>In our continuing effort to bring you the best in health and fitness, we are proud to offer the following products and services:</p>							
							<h3>Books</h3>
							<p><img class="about_image" src="images/layout/ultimatebooks.jpg" width=160 align="right">Check out the <a href="ultimate_fitness_books.php">Ultimate Fitness Books</a> and learn the most efficient and effective way to achieve your ideal physique. Based on Brad Schoenfeld's highly acclaimed High-Energy Fitness system of training, these are amongst today's most popular books on women's fitness.  With nearly half a million copies in print, they are guaranteed to set you on the right track to physique heaven--all you have to do is put in the effort!</p>
                            <p style="clear:both; height:12px;"></p>
                                                        <h3>Consulting/Speaking</h3>
                            <p><img class="about_image" src="images/layout/consult.gif" width=142 height=109 align="left">Looking for a speaker for your event? Brad is equally adept at delivering dynamic workshops and seminars for <a href="brad_schoenfeld_seminars.php"> fitness professionals</a> or custom-tailoring an informative and motivational keynote for the <a href="brad_schoenfeld_speaking.php"> general public</a> at large. Hire Brad to deliver a dynamic speaking engagement--you won't be dissapointed. Need help setting up a home gym? Find out how Brad can help with personalized <a href="home_gym_consulting.php">Home Gym Consulting</a>. Or, if you represent a corporation or institution that needs help in fitness education or facility design, check out our corporate consulting division, <a href="corporate_fitness_consulting.php">Corporate Fitness Concepts</a>. We help you achieve a healthy business!</p>
                            <p style="clear:both; height:12px;"></p>
                            <h3>Cybertraining</h3><br />
							<p><img class="about_image" src="images/layout/cyber1.gif" width=142 height=109 align="right">If you would like an Internet-based fitness program designed especially for you, check our our unique <a href="cybertraining.php">Cybertraining</a> program. Or if you are a fitness competitor, figure competitor, or bodybuilder seeking to optimize your physique, check out our <a href="online_competition_coaching.php">Online Competition Coaching</a>.</p>
                            <p style="clear:both; height:12px;"></p>
                            <hr align="center" />
                            <p style="clear:both; height:12px;"></p>
                            <h3>Downloads</h3>
                            <p><img class="about_image" src="images/layout/video-tape.gif" width=142 height=109 align="left">Need some instruction and/or motivation during your workout? Load up your iPod with our high quality audio files. Track your exercise sessions with our free workout log. They're all here on our <a href="fitness_downloads.php"> Fitness Downloads</a> page.</p>
                            
                            <p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
