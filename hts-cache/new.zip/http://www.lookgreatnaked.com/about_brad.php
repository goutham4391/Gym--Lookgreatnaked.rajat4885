<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Meet the Trainer Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
			
			<div id="main">

				<div id="main_center">

					<div id="content_lg">

						<h2>Meet the Trainer</h2>

						<div class="article">							

							<h3>Brad Schoenfeld, PhD, CSCS, CSPS, FNSCA </h3>

							<p><img class="about_image" height="360" alt="Brad Schoenfeld Bodybuilding Champion" hspace="4" src="images/layout/brad.gif" width="175" align="right" vspace="4" border="0" />Brad Schoenfeld, PhD, CSCS, CSPS, FNSCA, is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>

                            <p>Brad earned his masters degree in kinesiology/exercise science from the University of Texas at Permian Basin and his PhD at Rocky Mountain University where his dissertation focused on elucidating the mechanisms of muscle hypertrophy and their application to resistance training. He has published over 300 peer-reviewed research articles on exercise and sports nutrition, as well as editing multiple textbooks and authoring several textbook chapters. He acts as the Assistant Editor-in-Chief for the NSCA's <i>Strength and Conditioning Journal</i>, as well as serving on the editorial advisory board for numerous peer-reviewed exercise- and nutrition-related journals. 
														
                            <p>Brad is widely regarded as a "trainer of trainers." He is a tenured full professor in the Health Sciences Department at Lehman College in the Bronx, NY, and serves as the Graduate Director of the <a href="https://lehman.smartcatalogiq.com/en/2017-2019/Graduate-Bulletin/Academic-Programs-and-Courses/Health-Sciences/Human-Performance-and-Fitness-M-S-Program" target="blank">Human Performance and Fitness program</a>. Moreover, he is a dedicated mentor to young sports scientists, and has served as a chair or member on more than a dozen thesis and dissertation committees.</p>
   
														<p>Brad is a best-selling author of multiple fitness books including <A href="https://www.amazon.com/M-X-Muscle-Plan-2-0/dp/171820714X/">The M.A.X. Muscle Plan 2.0</a> (Human Kinetics, 2021), which has been widely referred to as the "muscle-building bible," and <a href="https://www.amazon.com/Strong-Sculpted-Brad-Schoenfeld/dp/149251456X" target="blank">Strong and Sculpted</a> (Human Kinetics, 2016), which details a cutting-edge body sculpting program targeted to women. Brad also has authored the seminal textbook <a href="https://www.amazon.com/Science-Development-Muscle-Hypertrophy-Schoenfeld/dp/1492597678/" target="blank">Science and Development of Muscle Hypertrophy</a> (Human Kinetics, 2020), the first text devoted to an evidence-based elucidation of the mechanisms and strategies for optimizing muscle growth. In total, Brad's books have sold over a half-million copies.</p>
														
                            <p>Brad has been published or appeared in such consumer publications as <I>Shape, Self, Fitness, Ladies Home Journal, Redbook, Cosmopolitan, Marie Claire, Woman's Day, Fit, The New York Times, New York Daily News, Gannett Suburban Papers, The Washington Post, Chicago Tribune, Oxygen, Musclemag, Ironman, Muscle and Fitness Hers,</I> and many, many others. He formerly served as a columnist for <I>Muscular Development</I> and <I>Fitness Rx</I> magazines, as well as the <I>Bodybuilding.com</I> website. He serves on the editorial board for <I>Men's Health Magazine</I> and is one of the most quoted experts in the fitness industry. He has been an on-air fitness expert for News 12 (Westchester, NY) and has appeared on over a hundred television shows including FOX Newschannel, CNN Headline News, CBS Evening News, UPN News, Good Day New York, Good Day LA, CBS New York Live, NBC Live at Five, and Today in New York, as well as hundreds of radio programs across the United States.</p>



							<img class="about_image" height="300" alt="Brad Schoenfeld Head Shot" hspace="4" src="images/layout/bradheadshot1s.jpg" width="200" align="left" vspace="4" border="0" />

                            

                            <p>Brad has consulted with numerous college and professional strength and conditioning programs including the Oklahoma Thunder, Sacramento Kings, North Carolina State University, Leicester Tigers Rugby Club, and England Rugby U20. He formerly served as the Sports Nutritionist for the New Jersey Devils hockey organization. He currently serves on on the scientific advisory board for Tonal Corporation, a leading manufacturer of home exercise equipment.</p>

                            
                            <p>Brad is a popular lecturer on both the professional and consumer level, having presented seminars and workshops in over 30 different countries across five continents. Professionally, he has lectured for the International Health, Racquet and Sportsclub Association (IHRSA), National Strength and Conditioning Association (NSCA), American College of Sports Medicine (ACSM), CanFitPro, Athletic Business Conference, Club Industry, International Society of Sports Nutrition (ISSN), and Academy of Nutrition and Dietetics (AND), among others.</p>

                          													
														<p>Brad is a Certified Strength and Conditioning Specialist and has been certified as a personal trainer by the NSCA, ACSM, ACE, AFAA, and CanFitPro. He previously served two terms as a member of the board of directors for the NSCA and was recognized with the distinction of fellowship by the organization. Brad is the recipient of multiple awards including NSCA Personal Trainer of the Year, NSCA Young Investigator of the Year, the Rocky Mountain University Outstanding Alumni Award, and the Dwight D. Eisenhower Fitness Award, presented by the United States Sports Academy for outstanding achievement in fitness and contributions to the growth and development of sport fitness through outstanding leadership activity. His efforts in the field have resulted in being named one of the 100 most influential people in health and fitness. </p> 

                            
                            <p>Brad is available for expert training, consulting, speaking, and freelance writing on all fitness related matters. You can follow him on <A href="https://www.instagram.com/bradschoenfeldphd/" target="blank">Instagram</a>, <A href="https://twitter.com/BradSchoenfeld" target="blank">Twitter</a>, and <A href="https://www.facebook.com/brad.schoenfeld.cscs/" target="blank">Facebook</a></p>

							

                            <p style="clear:both; height:12px;"></p>

                            

                            

                            							

							

						</div>

						

						

					</div>

					<div class="clear">&nbsp;</div>

				</div>

			</div>

			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	

