<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Fitness Articles: Exercise, Nutrition, Supplementation By Brad Schoenfeld</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content_lg">
						<h2>Archive of Fitness Articles</h2>
						<div class="article">							
							<h3>Fitness Articles</h3>
							<p><img class="about_image" src="images/layout/fitness_articles.png" width=200 height=150 border=0 alt="Fitness Articles" align="right">Below are the PDFs to my publications in peer-reviewed journals as well as links to various online articles I've either written or been interviewed in. I will continue to add to this list as additional articles are published.</p>
                            <p><ul class="article_links">                    

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/3_total_body_programs_for_big_arms" target="blank">3 total body programs for big arms</a><br>

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/4_reasons_youre_not_gaining_muscle" target="blank">4 reasons you're not gaining muscle</a><br>
										
										<li><a href="http://www.bornfitness.com/muscle-building-mistakes/" target="blank">5 muscle-building mistakes (and how to make gains)</a><br>
										
										<li><a href="https://www.t-nation.com/training/5-strategies-for-choosing-exercises" target="blank">5 Strategies for Choosing Exercises</a><br>

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/5_things_we_can_learn_from_arnold_about_building_muscle" target="blank">5 things we can learn from Arnold about building muscle</a><br>

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/6_lessons_learned_from_the_master_blaster" target="blank">6 lessons learned from the master blaster</a><br>

										<li><a href="articles/accentuating_muscular_development_through_active_insufficiency.pdf" target="blank">Accentuating muscular development through active insufficiency and passive tension</a><br>

										<li><a href="http://bretcontreras.com/an-interview-with-brad-schoenfeld-the-hypertrophy-specialist/" target="blank">An interview with Brad Schoenfeld - the hypertrophy specialist</a>  

										<li><a href="articles/applications_of_kettlebells_in_exercise_program_design.pdf" target="blank">Applications of kettlebells in exercise program design</a>    

										<li><a href="articles/are_all_hip_extension_exercises_created_equal.pdf" target="blank">Are all hip extension exercises created equal?</a><br>                                        

                    <li><a href="articles/are_deep_squats_a_safe_and_viable_exercise.pdf" target="blank">Are deep squats a safe and viable exercise?</a><br>

										<li><a href="http://nicktumminello.com/2011/05/are-leg-extensions-good-or-bad-safe-or-dangerous-effective-or-a-waste-of-time-functional-or-nonfunctional-exercise-expert-brad-schoenfeld-has-the-surprising-answers/" target="blank">Are leg extensions good or bad, safe or dangerous, effective or a waste of time, functional or non-functional?</a><br>

										<li><a href="articles/the_biomechanics_of_squat_depth.pdf" target="blank">The biomechanics of squat depth</a><br>

										<li><a href="articles/barbell_hip_thrust.pdf" target="blank">Barbell hip thrust</a><br>		

										<li><a href="https://www.t-nation.com/free_online_article/most_recent/blood_flow_restriction_training" target="blank">Blood Flow Restriction Training</a><br> 
										
										<li><a href="https://www.t-nation.com/free_online_article/most_recent/demolish_your_genetic_limits" target="blank">Demolish your genetic limits</a><br>
																
										<li><a href="https://www.t-nation.com/free_online_article/most_recent/do_pain_pills_impair_muscle_growth" target="blank">Do pain pills impair muscle growth?</a><br>								

										<li><a href="articles/do_single_joint_exercises_enhance_functional_fitness.pdf" target="blank">Do single joint exercises enhance functional fitness?</a><br>

										<li><a href="articles/does_cardio_after_an_overnight_fast_maximize_fat_loss.pdf" target="blank">Does cardio after an overnight fast maximize fat loss?</a><br>

										<li><a href="articles/does_exercise_induced_muscle_damage_play_a_role_in_skeletal_muscle_hypertrophy.pdf" target="blank">Does exercise-induced muscle damage play a role in skeletal muscle hypertrophy?</a><br>

										<li><a href="articles/effect_of_exercise_on_appetite_regulating_hormones_in_overweight_women.pdf" target="blank">Effect of exercise on appetite regulating hormones in overweight women</a><br>

										<li><a href="articles/effect_of_hand_position_on_EMG_activity_of_the_posterior_shoulder_musculature.pdf" target="blank">Effect of hand position on EMG activity of the posterior shoulder musculature</a><br>
										 
										<li><a href="articles/exercise and blood flow restriction.pdf" target="blank">Exercise and blood flow restriction</a><br>

										<li><a href="articles/high_intensity_interval_training.pdf" target="blank">High-intensity interval training: applications for general fitness training</a><br>

										<li><a href="articles/is_functional_training_really_functional.pdf" target="blank">Is functional training really functional?</a><br>		
										
										<li><a href="articles/is_muscle_soreness_indicative_of_muscle_development.pdf" target="blank">Is Post-Exercise Muscle Soreness a Valid Indicator of Muscular Adaptations?</a><br>
										 
										<li><a href="articles/is_there_a_minimum_threshold_of_resistance_training_intensity_for_hypertrophic_adaptations.pdf" target="blank">Is There a Minimum Intensity Threshold for Resistance Training-Induced Hypertrophic Adaptations?</a><br>
										 
										<li><a href="https://www.t-nation.com/free_online_article/most_recent/light_weights_for_big_gains" target="blank">Light Weights for Big Gains</a><br>		
										
										<li><a href="http://www.bodybuilding.com/fun/metabolic-resistance-training-build-muscle-torch-fat.html" target="blank">Metabolic resistance training: build muscle and torch fat at once</a><br>								

										<li><a href="http://www.jissn.com/content/10/1/5" target="blank">Nutrient timing revisited: is there a post-exercise anabolic window?</a><br>

										<li><a href="articles/omega3_fatty_acids_a_novel_fat_burner.pdf" target="blank">Omega-3 fatty acids: a novel fat-burner</a><br>

										<li><a href="articles/omega-3_fatty_acids_and_exercise.pdf" target="blank">Omega-3 fatty acids and exercise: a review of their combined effects on body composition and physical performance </a><br>  

										<li><a href="articles/postexercise_hypertrophic_adaptations.pdf" target="blank">Post-exercise hypertrophic adaptations: a re-examination of the hormone hypothesis</a><br>

									 	<li><a href="articles/post_rehabilitation_exercise_considerations_following_hip_arthroplasty.pdf" target="blank">Post-rehabilitation exercise considerations following hip arthroplasty</a><br>
										
										<li><a href="articles/potential_mechanisms_for_ a_role_of_metabolic_stress_in_hypertrophic_adaptations_to_resistance_training.pdf" target="blank">Potential mechanisms for a role of metabolic stress in hypertrophic adaptations to resistance training</a><br>

										<li><a href="http://www.stack.com/2014/02/13/qa-brad-schoenfeld-on-maximizing-muscle-growth/" target="blank">Q&A: Brad Schoenfeld on Maximizing Muscle Growth</a><br>
										
										<li><a href="articles/resistance_training_promotes_increase_in_intracellular_hydration_in_men_and_women.pdf" target="blank">Resistance training promotes increase in intracellular hydration in men and women</a><br>
										
										<li><a href="http://sportsnutritioninsider.insidefitnessmag.com/3707/sni-interviews-brad-schoenfeld-msc-cscs" target="blank">SNI Interviews Brad Schoenfeld, MSc, CSCS</a><br>
										
										<li><a href="articles/squatting_kinematics_and_kinetics.pdf" target="blank">Squatting kinematics and kinectis and their application to exercise performance</a><br>

										<li><a href="articles/biomechanics_of_the_Pushup.pdf" target="blank">The biomechanics of the push-up: implications for resistance training programs</a><br>

										<li><a href="articles/the_biomechanics_of_squat_depth.pdf" target="blank">The biomechanics of squat depth</a><br>
										
										<li><a href="http://www.jissn.com/content/10/1/53" target="blank">The effect of protein timing on muscle strength and hypertrophy: a meta-analysis</a><br>

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/the_hypertrophy_specialist" target="blank">The hypertrophy specialist</a><br>

										<li><a href="articles/long_lever_posterior_tilt_plank.pdf" target="blank">The long-lever posterior-tilt plank</a><br>

										<li><a href="articles/mechanisms_of_muscle_hypertrophy.pdf" target="blank">The mechanisms of muscle hypertrophy and their application to resistance training</a><br> 
										
										<li><a href="articles/the_muscle_pump.pdf" target="blank">The muscle pump: Potential mechanisms and applications for enhancing hypertrophic adaptations</a><br>

										<li><a href="http://www.bodybuilding.com/fun/the-myth-of-cardio-before-breakfast-debunked.html" target="blank">The myth of cardio before breakfast - debunked!</a><br>

										<li><a href="articles/the_role_of_fiber_types_in_muscle_hypertrophy.pdf" target="blank">The role of fiber types in muscle hypertrophy</a><br>
										
										<li><a href="http://www.louschuler.com/blog/the-science-of-muscle-growth/" target="blank">The science of muscle growth</a><br>

										<li><a href="articles/use_of_NSAIDs_for_exercise_induced_muscle_damage.pdf" target="blank">The use of nonsteroidal anti-inflammatory drugs for exercise-induced muscle damage: implications for skeletal muscle development</a><br>

										<li><a href="articles/use_of_specialized_training_techniques.pdf" target="blank">The use of specialized training techniques to maximize muscle hypertrophy</a><br>

										<li><a href="articles/to_crunch_or_not_to_crunch.pdf" target="blank">To crunch or not to crunch: an evidence-based examination of spinal flexion exercises, their potential risks, and their applicability to program design.</a><br>

										<li><a href="http://www.t-nation.com/free_online_article/most_recent/to_crunch_or_not_to_crunch" target="blank">To crunch or not to crunch (consumer version)</a><br>

										<li><a href="articles/upright_row_implications_for_preventing_subacromial_impingement.pdf" target="blank">The upright row: implications for preventing subacromical impingement</a><br>

										<li><a href="http://www.burnthefatblog.com/archives/2012/11/what-makes-muscles-grow.php" target="blank">What makes muscles grow?</a><br>

                    <li><a href="http://www.t-nation.com/free_online_article/most_recent/why_bodybuilders_are_more_jacked_than_powerlifters" target="blank">Why bodybuilders are more jacked than powerlifters</a><br>

										</ul></p>							
							<p style="clear:both; height:12px;"></p>
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
