<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">

<html xmlns="http://www.w3.org/1999/xhtml">
  
 <head>
	<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
    <meta name="keywords" content="female fitness, strength training, sculpting, stength training, exercise, strength, fitness, look great, muscle, resistance, fitness dvd, exercise dvd, body sculpting, bodysculpting, look great naked, Brad Schoenfeld, cardio, shape, weights, muscle, ,muscle tone, aerobics, training, womens bodybuilding, women's bodybuilding">
		  <title>Lookgreatnaked.com - - Science and Development of Muscle Hypertrophy</title>
			<link rel="stylesheet" href="css/styles.css" type="text/css" media="screen, projection" />
            <link rel="shortcut icon" type="image/x-icon" href="http://www.lookgreatnaked.com/favicon.ico">
            <script type="text/javascript" src="../flowplayer/example/flowplayer-3.1.4.min.js"></script>
 </head>

 <body>
	<div id="wrapper">
		
			<div id="header">
				<div id="header_center">
					<div id="header_top">
						<a href='index.php'><img id="logo" src="images/layout/logo.jpg" alt='' border='' /></a>
						<div id="logo_right">The official site of Brad Schoenfeld</div>
					</div>
					<div id="topnav">				
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
					</div>
					<div id="content">
						<img id="slogan" src="images/layout/slogan.png">
						<div id="search">
                             <form action='http://www.lookgreatnaked.com/blog/' id='searchform' method='get'>
                                  <input type='text' name='s' id='s' value=''>
                                  <input type='image' src='images/layout/search_button.png' name='submit'>
                             </form>
                        </div>

						<div>							
							<div class='header_box'>
								<img src='images/layout/latest_post.png'>
																									<p>
Progressive overload is a well-established principle for achieving continued progress in resistance training programs. In general terms, progressive overload can be defined as consistently challenging the neuromuscular system beyond its present capacity. It’s commonly accepted that this requires ...</p>									<a href='http://www.lookgreatnaked.com/blog/do-you-have-to-add-load-to-the-bar-to-build-muscle/' class="more"><img src='http://www.lookgreatnaked.com/blog/wp-content/themes/white-buck/images/more_button.png'></a>
									  								                                							</div>
							<div class='header_box'>
								<img src='images/layout/about_brad.png'>
                                <p>Brad Schoenfeld, Ph.D, C.S.C.S., is an internationally renowned fitness expert and widely regarded as one of the leading authorities on body composition training (muscle development and fat loss). He is a lifetime drug-free bodybuilder, and has won numerous natural bodybuilding titles.</p>
								<a href='about_brad.php' class="more"><img src='images/layout/more_button.png'></a>
							</div>							
						</div>
					</div>
				</div>				
			</div>
						<div id="main">
				<div id="main_center">
					<div id="content">
						<h2>Products and Services</h2>
						<div class="article">							
							<h3>Science and Development of Muscle Hypertrophy</h3>
							<p><img class="book_cover" src="images/products/Science_and_Development_of_Muscle_Hypertrophy.jpg" width=114 height=149 border=0 alt="Science and Development of Muscle Hypertrophy" align="left"><font size="+1">Science and Development of Muscle Hypertrophy</font><br>Brad Schoenfeld, PhD<br></p>
                            <p> USA Price : <b>$69</b>.<br><A HREF="https://www.amazon.com/Science-Development-Muscle-Hypertrophy-Schoenfeld-dp-1492597678/dp/1492597678/" target="blank">BUY IT NOW!</A> from Amazon.com at a discount!<p><font size="-1">Format: Paperback<br>ISBN: 149251960X</font></p>
                            							
							<p style="clear:both; height:12px;"></p>
							<h3>Audiences:</h3>
                            <p>Anyone who wants to optimize muscular development!</p>
							<p style="clear:both; height:12px;"></p>                        
                        
                        	                            
                            <h3>About Science and Development of Muscle Hypertrophy. . .</h3>
                            <p>Muscle hypertrophy - defined as an increase in muscular size - is one of the primary outcomes of resistance training. Science and Development of Muscle Hypertrophy is a comprehensive compilation of science-based principles to help professionals develop muscle hypertrophy in athletes and clients. With more than 825 references and applied guidelines throughout, no other resource offers a comparable quantity of content solely focused on muscle hypertrophy. Readers will find up-to-date content so they fully understand the science of muscle hypertrophy and its application to designing training programs.<br>
                            
                            <br>
                            
                            Written by Brad Schoenfeld, PhD, a leading authority on muscle hypertrophy, this text provides strength and conditioning professionals, personal trainers, sport scientists, researchers, and exercise science instructors with a definitive resource for information regarding muscle hypertrophy - the mechanism of its development, how the body structurally and hormonally changes when exposed to stress, ways to most effectively design training programs, and current nutrition guidelines for eliciting hypertrophic changes. The full-color book offers several features to make the content accessible to readers:<br>  
                            
                            <br>
                            
                            --Research Findings sidebars highlight the aspects of muscle hypertrophy currently being examined to encourage readers to re-evaluate their knowledge and ensure their training practices are up to date.<br>
                            
                            <br>
                            
														--Practical Applications sidebars outline how to apply the research conclusions for maximal hypertrophic development. <br>
                            
                            <br>
														
														--Comprehensive subject and author indexes optimize the book's utility as a reference tool.<br>
                            
                            <br>
														
														--An image bank containing most of the art, photos, and tables from the text allows instructors and presenters to easily teach the material outlined in the book.<br>
                            
                            <br>
														
														Although muscle hypertrophy can be attained through a range of training programs, this text allows readers to understand and apply the specific responses and mechanisms that promote optimal muscle hypertrophy in their athletes and clients. It explores how genetic background, age, sex, and other factors have been shown to mediate the hypertrophic response to exercise, affecting both the rate and the total gain in lean muscle mass. Sample programs in the text show how to design a three- or four-day-per-week undulating periodized program and a modified linear periodized program for maximizing muscular development.<br>
                            
                            <br>
														
                            Science and Development of Muscle Hypertrophy is an invaluable resource for strength and conditioning professionals seeking to maximize hypertrophic gains and those searching for the most comprehensive, authoritative, and current research in the field.</p>
                            <p style="clear:both; height:12px;"></p>
                            
                            <h3>About the Author. . .</h3>
                            <p><b>Brad Schoenfeld, PhD, CSCS, CSPS, CPT, FNSCA</b> is widely regarded as one of the leading strength and fitness experts in the United States. The 2011 NSCA Personal Trainer of the Year is a lifetime drug-free bodybuilder who has won numerous natural bodybuilding titles, including the All-Natural Physique and Power Conference (ANPPC) Tri-State Naturals and USA Mixed Pairs crowns. As a personal trainer, Schoenfeld has worked with numerous elite-level physique athletes, including many top pros. Also, he was elected to the National Strength and Conditioning Association's Board of Directors in 2012.<br>
                            
                            <br>
                            
                            Schoenfeld is the author of multiple consumer-oriented fitness books, including <i>The M.A.X. Muscle Plan</i> and <i>Strong and Sculpted</i> (formerly <i>Sculpting Her Body Perfect</i>). He is a regular columnist for Muscular Development magazine, has been published or featured in virtually every major fitness magazine (including <i>Muscle and Fitness</i>, <i>Men's Health</i>, <i>Ironman</i>, <i>Oxygen</i>, and <i>Shape</i>), and has appeared on hundreds of television shows and radio programs across the United States.<br> 
                            
                            <br>
                            
                            Schoenfeld earned his PhD in health promotion and wellness at Rocky Mountain University, where his research focused on elucidating the mechanisms of muscle hypertrophy and their application to resistance training. He has published more than 100 peer-reviewed scientific papers and serves on the editorial advisory boards for several journals, including the <i>Journal of Strength and Conditioning Research</i> and <i>Journal of the International Society of Sports Nutrition</i>. He is an assistant professor of exercise science at Lehman College in the Bronx, New York, and heads their human performance laboratory. </p>
                            <p style="clear:both; height:12px;"></p>
                            
                            <h3>Contents. . .</h3>
                            <p>Chapter 1. Hypertrophy-Related Responses and Adaptations to Exercise Stress<br>

                            Chapter 2. Mechanisms of Hypertrophy<br>
                            
                            Chapter 3. Role of Resistance Training Variables in Hypertrophy<br>
                            
                            Chapter 4. Role of Aerobic Training in Hypertrophy <br>
                            
                            Chapter 5. Factors in Maximal Hypertrophic Development<br>
                            
                            Chapter 6. Program Design for Maximal Hypertrophy <br>
                            
                            Chapter 7. Nutrition for Hypertrophy <br>
                            
                                                        </p>
                            
                            <p><script type="text/javascript" src="http://books.google.com/books/previewlib.js"></script>

							<script type="text/javascript">
                            
                            GBS_insertPreviewButtonPopup('ISBN:149251960X');
                            
                            </script></p>
                            
                            <p style="clear:both; height:12px;"></p>
                        </div>
						
						
					</div>
                    <div id="rightcolumn">
						<div class="widget">
							<h3 class="title"><span>What People are Saying. . .</span></h3>
							<p style="clear:both; height:12px;"></p>
                                                   
                                                   
                          
                            <i>"Brad Schoenfeld's scientific approach to strength training is much needed in this day and age."</i><br><br><b>Bret Contreras, MA<br>Author<i>Bodyweight Training</i></b>
                            
                            </p>	
                            <p style="clear:both; height:8px;"></p>						
						</div>
						
						
					</div>
					<div class="clear">&nbsp;</div>
				</div>
			</div>
            <script language="JavaScript">
    
			$f("flowplayerholder", "../flowplayer/flowplayer-3.1.5.swf", {
				clip: {
					url: 'videos/MAX_Muscle_Plan_trailer.flv',
					autoPlay: false,
					autoBuffering: true
				}
			});
			</script>
			<div id="footer">
				<div id="footer_center">
					<div id="clients"><img src='images/layout/clients.png'></div>
					<div id='testimonial'>
						<blockquote>
							<span class="bqstart">&#8220;</span>
							Brad Schoenfeld has a brilliant combination of technical expertise and in the trenches field experience. When Brad speaks, I listen.
						  <span class="bqend">&#8221;</span>
						</blockquote>
						<div class="customer_name">- John Meadows<br /><font style="color:#CC3">Nationally Ranked<br />Bodybuilder and Trainer</font></div>
						<div id="social">
							<a href='http://www.facebook.com/brad.schoenfeld.cscs' target='_blank'><img src="images/layout/fb.png"></a>
							<a href='http://twitter.com/bradschoenfeld' target='_blank'><img src="images/layout/tw.png"></a>
							<a href='http://www.linkedin.com/in/bradschoenfeld' target='_blank'><img src="images/layout/in.png"></a>
							<a href='http://www.youtube.com/lookgreatnaked4life' target='_blank'><img src="images/layout/yt.png"></a>
						</div>
					</div>
					<div id="footer_nav">
						<ul>
							<li><a href='http://www.lookgreatnaked.com/index.php'>Home</a></li>
							<li><a href='http://www.lookgreatnaked.com/newsletter.php'>Newsletter</a></li>
							<li><a href='http://www.lookgreatnaked.com/about_brad.php'>About</a></li>
							<li><a href='http://www.lookgreatnaked.com/fitness_articles_by_brad_schoenfeld.php'>Articles</a></li>
							<li><a href='http://www.lookgreatnaked.com/blog/'>Blog</a></li>
							<li><a href='http://www.lookgreatnaked.com/products.php'>Product/Services</a></li>
							<li><a href='http://www.lookgreatnaked.com/media_and_press.php'>Media/Press</a></li>
							<li><a href='http://www.lookgreatnaked.com/testimonials.php'>Testimonials</a></li>
							<li><a href='http://www.lookgreatnaked.com/contact_brad.php'>Contact</a></li>											
						</ul>
						<p id='copyright'>2013 Copyright &copy; Brad Schoenfeld and LookGreatNaked.com</p>
                        <p style="clear:both;"></p> 
                        <p style="width:960px; color:#fff; text-align:center;">Website Designed and Developed by:&nbsp;&nbsp; <a href="http://www.whitebuckmedia.com" style="color:#fff; text-align:center;" target="_blank">White Buck Media and Hosting</a></p>
					</div>
				</div>				
			</div>
		</div>
	</div>
 </body>
</html>
	
